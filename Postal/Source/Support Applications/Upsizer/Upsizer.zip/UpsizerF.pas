unit UpsizerF;

interface

uses
  TxnTranslateU,
  DBCreateU,
  SAvePosFormU,
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, DBTables, Db, ExtCtrls, ComCtrls;

type
  TUpsizerForm = class(TSavePosForm)
    LogMemo: TMemo;
    TopPanel: TPanel;
    FromLabel: TLabel;
    FromAliasComboBox: TComboBox;
    ToAliasLabel: TLabel;
    ToAliasComboBox: TComboBox;
    TableLabel: TLabel;
    TableComboBox: TComboBox;
    UpsizeButton: TButton;
    FromTable: TTable;
    ToTable: TTable;
    ProgressBar: TProgressBar;
    CreateButton: TButton;
    TransactButton: TButton;
    FillButton: TButton;
    procedure FormCreate(Sender: TObject);
    procedure FromAliasComboBoxChange(Sender: TObject);
    procedure UpsizeButtonClick(Sender: TObject);
    procedure CreateButtonClick(Sender: TObject);
    procedure TransactButtonClick(Sender: TObject);
    procedure FillButtonClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    procedure AppExcept(Sender : TObject; E : Exception);
  end;

var
  UpsizerForm: TUpsizerForm;

implementation

{$R *.DFM}

function  CreateTable(SourceAlias, DestAlias, TableName : String) : Boolean;
var
  SourceTable, DestTable  : TTable;
begin
  Result := False;
  SourceTable := TTable.Create(nil);
  DestTable := TTable.Create(nil);
  try
    SourceTable.DatabaseName  := SourceAlias;
    DestTable.DatabaseName    := DestAlias;
  finally
    SourceTable.Free;
    DestTable.Free;
  end;
end;

procedure TUpsizerForm.AppExcept(Sender : TObject; E : Exception);
begin
  LogMemo.Lines.Add(E.Message);
end;

procedure TUpsizerForm.FormCreate(Sender: TObject);
begin
  Application.OnException := AppExcept;
  Session.GetAliasNames(FromAliasComboBox.Items);
  Session.GetAliasNames(ToAliasComboBox.Items);
end;

procedure TUpsizerForm.FromAliasComboBoxChange(Sender: TObject);
begin
  Session.GetTableNames(FromAliasComboBox.Text, '', False, False, TableComboBox.Items);
end;

procedure TUpsizerForm.UpsizeButtonClick(Sender: TObject);
var
  FieldIndex : Integer;
begin
  FromTable.Close;
  ToTable.Close;
  FromTable.DatabaseName  := FromAliasComboBox.Text;
  FromTable.TableName     := TableComboBox.Text;
  ToTable.DatabaseName    := ToAliasComboBox.Text;
  ToTable.TableName       := TableComboBox.Text;
  FromTable.Open;
  ToTable.Open;
  ProgressBar.Max := FromTable.RecordCount;

  FromTable.First;
  While not FromTable.Eof do
  begin
    ToTable.Append;
    For FieldIndex := 0 to FromTable.FieldCount -1 do
      ToTable.Fields[FieldIndex].Assign(FromTable.Fields[FieldIndex]);
    FromTable.Next;
    ProgressBar.Position := ProgressBar.Position +1; 
  end;
end;

procedure TUpsizerForm.CreateButtonClick(Sender: TObject);
begin
  CreateAlltables('PSL Script Test');

end;

procedure TUpsizerForm.TransactButtonClick(Sender: TObject);
begin
  With TTxnTranslate.TranslateQuery('', 'Select * from txnlog') do
  begin
    AddToTable('PSL','Transact');
    Free;
  end;

end;

procedure TUpsizerForm.FillButtonClick(Sender: TObject);
begin
  FillAllTables('PSL', 'PSL Script Test');
end;

end.
