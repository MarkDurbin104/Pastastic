unit DatabaseUtils;

interface


implementation


end.
 