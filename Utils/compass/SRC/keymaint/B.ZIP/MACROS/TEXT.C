if (fred) {
}
