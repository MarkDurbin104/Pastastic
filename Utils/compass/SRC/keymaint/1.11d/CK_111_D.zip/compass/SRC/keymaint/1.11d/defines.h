//===============|========================================================|
//               |                                                        |
// Module        | DEFINES.H                                               |
//               |                                                        |
// Project       | Compass In-Unit Trading Project                        |
//               |                                                        |
// Description   | File I/O definitions for use by COMPKEY.C              |
//               |                                                        |
// Functions     | None                                                   |
//               |                                                        |
//===============|========================================================|
//               |                                                        |
// Copyright (c) | Unisys Limited                                         |
//               | 22 Southwark Bridge Road                               |
//               | London SE1 9HB                                         |
//               |                                                        |
// Author        | Mark Durbin                                            |
//               | P.S.L.                                                 |
//               | 160 Charles street, Greenhithe, Kent. DA9 9AJ          |
//               |                                                        |
//===============|========================================================|
// Date          | Modifications                                 | By     |
//===============|===============================================|========|
// 10/05/96      | Initial Version                               | MJD    |
//===============|========================================================|
//               |                                               |        |
//===============|========================================================|


#ifndef __DEFINES_H // entry sentry
#define __DEFINES_H

#define BOXTOPLEFT  "���" // character for top left corner of box
#define BOXTOPRIGHT "���" // character for top right corner of box
#define BOXBOTLEFT  "���" // character for bottom left corner of box
#define BOXBOTRIGHT "ټ�" // character for bottom right corner of box
#define BOXLEFT     "���" // character for left (and right) side of box
#define BOXRIGHT    "���" // character for left (and right) side of box
#define BOXTOP      "���" // character for top (and bottom) side of box
#define BOXBOTTOM   "���" // character for top (and bottom) side of box
#define BOXLEFTIN   "���" // character for cut in from left side of box
#define BOXTOPIN    "���" // character for cut in from top side of box
#define BOXRIGHTIN  "���" // character for cut in from right side of box
#define BOXBOTIN    "���" // character for cut in from bottom side of box
#define BOXCROSS    "���" // character for crossing lines in box

#define SEARCHHELP1     1
#define SEARCHHELP2     2
#define STARTHELP       3
#define MAINHELP        4
#define EDITHELP        5

#define MAXSTRLEN   200   // the maximum length of a string

#define DIRECT_VIDEO_ACCESS

#define LINEVAL(a) ( (INT)(a>>24    ))           // bits 31-24 
#define COLVAL(a)  (((INT)(a>>16    ))&0xFF)     // bits 23-16
#define KEYVAL(a)  ( (INT)(a&0xFFFFL))           // bits 15-00

#define TOPBTYPE 0
#define BOTBTYPE 0
#define MENUBTYPE 0
#define KEYMAPBTYPE 1

#define GRIDTOP      4
#define GRIDLEFT     2
#define GRIDKEYWID   11
#define GRIDKEYHGT   5
#define GRIDNUMKEYX  5
#define GRIDNUMKEYY  4
#define GRIDBOT      (GRIDTOP+(GRIDNUMKEYY*GRIDKEYHGT))
#define GRIDRIGHT    (GRIDLEFT+(GRIDNUMKEYX*GRIDKEYWID))

#define MENUTOP     4
#define MENUBOTTOM  18
#define MENULEFT    56
#define MENURIGHT   78
#define MENULENGTH  (MENUBOTTOM-MENUTOP)

#define MAXFIELDLEN 100

#define NUMBCOLOUR  30

#ifdef DIRECT_VIDEO_ACCESS
//#define SCREENBASE  0xB8000000L // the Base address of colour screen memory
#define SCREENBASE  MK_FP(__SegB800,0) // the Base address of colour screen memory
#endif

#define CFGPATH     "\\KEYMAINT\\"
#define PLU_KEYPATH CFGPATH "%-2.2s"
#define ISSPATH     "\\ISS\\"
#define ISSPUPATH   "\\ISS\\POSUPDT\\"
#define POSUPPATH   ISSPATH "\\ISS\\"
#define CONFIGFILE  CFGPATH "KEYMAINT.CFG"
#define AUDITFILE   CFGPATH "KEYMAINT.AUD"
#define PRINTERFILE CFGPATH "PRINTER.INI"
#define COLOURFILE  CFGPATH "COLOURS.INI"
#define LAYOUTFILE  CFGPATH "LAYOUT.%-3.3s"
#define KEYMAPFILE  PLU_KEYPATH "\\KEYMAP%02d.%-3.3s"
#define PLUFILE     PLU_KEYPATH "\\PLU%02d.%-3.3s"
#define KEYMAPBACK  PLU_KEYPATH "\\KEYMAP%02d.BAK"
#define PLUBACK     PLU_KEYPATH "\\PLU%02d.BAK"
#define COMERROR    PLU_KEYPATH "\\COMERROR.LOG"
#define TERMERROR   PLU_KEYPATH "\\TERMERR.LOG"
#define STOREDAT    PLU_KEYPATH "\\STORE.DAT"
#define TERMDAT     PLU_KEYPATH "\\TERM.DAT"
#define SEQFILE     PLU_KEYPATH "\\COMPASS.SEQ"
#define POLLFILE    PLU_KEYPATH "\\TESTPOLL.SEQ"
#define RPLUFILE    ISSPUPATH "POS%-3.3s%-2.2s.FLT"
#define LRPLUFILE   PLU_KEYPATH "\\LOCALPLU.%-3.3s"
#define LRPLUBACK   PLU_KEYPATH "\\LOCALPLU.BAK"
#define HELPFILE    CFGPATH "HELPFILE.%-3.3s"
#define XMITPATH1   CFGPATH "XMT"
#define XMITPATH2   XMITPATH1 "\\%s"
#define XMITPLUFILE "PLU%-3.3s%-2.2s.XMT"
#define XMITKEYFILE "OSP%-3.3s%-2.2s.XMT"
#define XMITBATCH   CFGPATH "COMPKEYX %-2.2s %02d"
#define TERMBATCH   CFGPATH "TESTTERM %-2.2s %02d"
#define TXPLU       "\\OMCOM\\OMRONXMT\\PLU_COMP.XMT"
#define TXDEPT      "\\OMCOM\\OMRONXMT\\DEP_COMP.XMT"
#define UNLINK1     "\\OMCOM\\OMRONDAT\\POST.DAT"
#define UNLINK2     "\\OMCOM\\POST.DAT"


#define PCL             1
#define EPSON           2

#define PRINTXOFS       61
#define PRINTXSTEP      213
#define PRINTXMID       (PRINTXSTEP/2)
#define PRINTCHARWID    (PRINTXSTEP/10)

#define PRINTYOFS       94
#define PRINTYSTEP      171
#define PRINTLINESTEP   40
#ifdef __BORLANDC__
#define MENUXCHAR '�'
#else
#define MENUXCHAR 'X'
#endif

#endif // __DEFINES_H

